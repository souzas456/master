PollType
========

.. autoclass:: pyrogram.enums.PollType()
    :members:

.. raw:: html
    :file: ./cleanup.html