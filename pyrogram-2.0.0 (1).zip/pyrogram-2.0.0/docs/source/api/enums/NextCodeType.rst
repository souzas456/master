NextCodeType
============

.. autoclass:: pyrogram.enums.NextCodeType()
    :members:

.. raw:: html
    :file: ./cleanup.html